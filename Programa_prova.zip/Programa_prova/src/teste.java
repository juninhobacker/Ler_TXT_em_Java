Stack pilha;

String objeto = "Teste";

pilha.push(objeto);