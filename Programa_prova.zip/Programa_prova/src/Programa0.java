import java.awt.*;
import java.awt.event.*;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import javax.swing.*;

public class Programa0 extends JFrame
        
implements ActionListener, WindowListener {    
    JButton botao1;
    JTextArea textArea;
    JScrollPane scrollPane;
    int largura, altura;
    char[] nm = {65, 100, 105, 108, 115, 111, 110, 32, 65, 110,
                116, 111, 110, 105, 111, 32, 80, 101, 114, 101,
                105, 114, 97, 32, 74, 117, 110, 105, 111, 114};
    
    String str = new String(nm);    
    FileInputStream arquivo;
    DataInputStream leitor;

    String lista[];
    String vogais[];
    
    public Programa0() {
        largura = 432;
        altura = largura / 2;
        setTitle(str);
        setBounds(400,200,largura,altura);
        setLayout(null);
        getContentPane().setBackground(Color.white);
        textArea = new JTextArea(5, 20);
        JScrollPane scrollPane = new JScrollPane(textArea); 
        textArea.setEditable(false);
        textArea.setBounds((largura/2)-100, (altura/2)-80, 200, 80);
        textArea.setBackground(Color.gray);
        getContentPane().add(textArea);
        botao1 = new JButton("Sair");
        botao1.setBounds((largura/2)-50, altura-90, 100, 25);
        botao1.setBackground(new Color(0, 185, 125));
        botao1.addActionListener(this);
        getContentPane().add(botao1);
        addWindowListener(this);
        lerArquivo();
    }
    
        private void lerArquivo() {
        int caractere;
        char compVogais;
        String s;
        
        try {
            arquivo = new FileInputStream("C:\\Users\\junin\\Ambiente de Trabalho\\AED3\\Programa0\\prova.txt");
            leitor = new DataInputStream(arquivo);

            caractere = 0;
            s = "";
            while (caractere != -1) {
                caractere = leitor.read();
                if (caractere != -1) {
                    s = s + (char) caractere;
                }
            }
            arquivo.close();
            System.out.println("Bytes recuperados do arquivo = " + s);

            lista = s.split(" ");
            for (int i = 0; i < lista.length; i++) {
                System.out.println(lista[i]);
                compVogais = lista[i].charAt(0);
                System.out.println(compVogais);
                
                if (compVogais == 'a'||compVogais == 'e'||compVogais == 'i'||compVogais == 'o'
                  ||compVogais == 'u'||compVogais == 'A'||compVogais == 'E'||compVogais == 'I'
                  ||compVogais == 'O'||compVogais == 'U'){textArea.insert(lista[i] + " ", textArea.getCaretPosition());}
            }            

        } catch (IOException erro) {
            System.out.println("Adilson, o arquivo não encontrado...");
        }
    }
    
    
    public static void main(String args[]) {
        JFrame janela = new Programa0();
        janela.setVisible(true);
    }

    @Override public void actionPerformed(ActionEvent e) {if (e.getSource() == botao1) {this.dispose(); System.exit(1);}}
    @Override public void windowOpened(WindowEvent e) {    }
    @Override public void windowClosing(WindowEvent e) {this.dispose(); System.exit(1);}
    @Override public void windowClosed(WindowEvent e) {this.dispose(); System.exit(1);}
    @Override public void windowIconified(WindowEvent e) {    }
    @Override public void windowDeiconified(WindowEvent e) {    }
    @Override public void windowActivated(WindowEvent e) {    }
    @Override public void windowDeactivated(WindowEvent e) {    }
}
